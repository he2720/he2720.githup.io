<template>
  <div class="login_container">
    <img
      src="../assets/login_background2.png"
      width="100%"
      height="100%"
      alt=""
    />
    <div class="login_box">
      <div class="avatar_box">
        <img src="../assets/touXiang.jpg" alt="" />
      </div>
      <el-form
        ref="loginFormRef"
        :model="loginForm"
        :rules="loginFormRules"
        label-width="0px"
        class="login_form"
      >
        <el-form-item prop="username">
          <el-input
            v-model="loginForm.username"
            prefix-icon="iconfont icon-user"
            placeholder="用户名"
          ></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            prefix-icon="iconfont icon-3702mima"
            type="password"
            placeholder="密码"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-radio v-model="loginForm.radio" label="1" class="radio_warp"
            >管理员</el-radio
          >
          <el-radio v-model="loginForm.radio" label="-1" class="radio_warp"
            >副管理员</el-radio
          >
          <el-radio v-model="loginForm.radio" label="0" class="radio_warp"
            >标注员</el-radio
          >
        </el-form-item>
        <el-form-item class="btns">
          <el-link @click="dialogVisible = true">忘记密码</el-link>&nbsp
          <el-button @click="register">注册</el-button>
          <el-button @click="login">登录</el-button>
          <el-button type="info" @click="resetLoginForm">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <el-dialog title="修改密码" :visible.sync="dialogVisible" width="30%">
      <el-input v-model="reset.username" placeholder="用户名"></el-input>
      <el-input v-model="reset.phone" placeholder="手机号" class="phone"></el-input><el-button type="primary" size="small">发送验证码</el-button>
      <el-input
        v-model="reset.yanzheng"
        placeholder="验证码"
      ></el-input>
      <el-input
        v-model="reset.newpassword"
        placeholder="密码"
        type="password"
      ></el-input>
      <el-input
        type="password"
        v-model="reset.checkpassword"
        placeholder="确认密码"
      ></el-input>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="resetPass">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dialogVisible: false,
      reset: {
        username: "",
        phone:"",
        yanzheng:"",
        newpassword: "",
        checkpassword: "",
      },
      loginForm: {
        username: "",
        password: "",
        radio: "1",
      },
      loginFormRules: {
        username: [
          { required: true, message: "请输入登录名称", trigger: "blur" },
          {
            min: 3,
            max: 10,
            message: "长度在 3 到 10 个字符",
            trigger: "blur",
          },
        ],
        password: [
          { required: true, message: "请输入登录密码", trigger: "blur" },
          {
            min: 3,
            max: 15,
            message: "长度在 5 到 15 个字符",
            trigger: "blur",
          },
        ],
      },
    };
  },
  methods: {
    resetLoginForm() {
      this.$refs.loginFormRef.resetFields();
    },
    login() {
      this.$refs.loginFormRef.validate(async (valid) => {
        if (!valid) return;
        let data = JSON.stringify(this.loginForm);
        console.log(data);
        this.$axios({
          //请求类型
          method: "POST",
          contentType: "application/x-www-form-urlencoded",
          //URL
          url: "http://82.156.183.82:8000/login/",
          //设置请求体
          data: data,
        }).then((response) => {
          console.log(response.data);
          if (response.data == "cookie") {
            this.$message.success("登录成功");
            window.sessionStorage.setItem("username", this.loginForm.username);
            window.sessionStorage.setItem("identity", this.loginForm.radio);
            this.$router.push("/home");
            // window.sessionStorage.setItem('token', res.data.token)
          } else if (response.data == "您已在其它地方登陆，请勿重复登录") {
            this.$message.error("您已在其它地方登陆，请勿重复登录！");
          } else {
            this.$message.error("登录失败！");
          }
        });
      });
    },
    register() {
      this.$router.push("/register");
    },
    resetPass() {
      if (this.reset.newpassword != this.reset.checkpassword) {
        this.$message.error("两次密码不一致");
        return;
      }
      let that = this;
      let data = JSON.stringify(this.reset);
      console.log(data);
      this.$axios({
        method: "POST",
        url: "http://82.156.183.82:8000/forgetpassword/",
        data: data,
      }).then((response) => {
        console.log(response.data);
        if (response.data == "修改成功") {
          that.$message({
            message: "修改成功",
            type: "success",
          });
          that.dialogVisible = false;
        } else {
          that.$message.error("修改失败");
        }
      });
    },
  },
};
</script>

<style lang="less" scoped>
.login_container {
  background-color: #121213;
  height: 100%;
  width: 100%;
}
.login_box {
  width: 450px;
  height: 350px;
  background-color: rgb(39, 40, 43);
  border: rgb(47, 86, 145) solid 10px;
  border-radius: 15%;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  .avatar_box {
    height: 130px;
    width: 130px;
    border: 1px solid rgb(17, 17, 17);
    border-radius: 50%;
    padding: 10px;
    box-shadow: 0 0 10px rgb(17, 16, 16);
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgb(80, 98, 121);
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #eee;
    }
  }
}
.login_form {
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: 0 20px;
  box-sizing: border-box;
}
.btns {
  display: flex;
  justify-content: flex-end;
}
.radio_warp {
  color: #fff;
}
.phone{
  width: 200px;
}
</style>